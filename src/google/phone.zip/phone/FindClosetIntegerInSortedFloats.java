package google.phone;

public class FindClosetIntegerInSortedFloats {

	public static int findCloset1(double[] nums, int target) {
		if(nums == null || nums.length == 0) return Integer.MAX_VALUE;
		
		double minDiff = Double.MAX_VALUE; 
		int closet = 0;
		for(int i = 0; i < nums.length; i++) {
			double diff = Math.abs(nums[i] - target);
			if(diff < minDiff) {
				minDiff = Math.abs(nums[i] - target);
				closet = i;
			}
		}
		return closet;
	}
	public static int findCloset2(double[] nums, int target) {
		
		return binarySearch(nums, 0, nums.length-1, target);
	}
	private static int binarySearch(double[] nums, int start, int end, int target) {
		
		while(start + 1 < end) {
			int mid = start + (end - start)/2;
			
			int compare;
			if(nums[mid] > target) {
				compare = 1;
			} else if(nums[mid] < target) {
				compare = -1;
			} else {
				if(nums[mid] == target) compare = 0;
				else if(nums[mid] < target) compare = -1;
				else compare = 1;
			}
			
			if(compare > 0) {
				start = mid+1;
			}else if(compare < 0) {
				end = mid-1;
			} else return mid;
		}
		if(nums[start] == target) return start;
		if(nums[end] == target) return end;
		return -1;
		
	}
	public static void main(String[] args) {
		double[] d= {1.2,2.5,9.3};
		System.out.println(findCloset1(d, 5));
		System.out.println(findCloset2(d,5));
	}
}
