package google.phone;

public class TreeNode {
	TreeNode left;
	TreeNode right;
	TreeNode pre;
	TreeNode next;
	int val;
	TreeNode(int val) {this.val = val;}
}
