package google.phone;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FindMeetingSchedule {
	class Interval {
		int start;
		int end;
		Interval(int start, int end) {
			this.start = start;
			this.end = end;
		}
	}
	
	public int findMeetingTime(List<Interval> intervals1, List<Interval> intervals2, int time) {
		intervals1 = mergeInterval(intervals1);
		intervals2 = mergeInterval(intervals2);
		List<Interval> newIntervals = new ArrayList<Interval>(intervals1);
		for(Interval it : intervals2) {
			newIntervals.add(it);
		}
		Collections.sort(newIntervals, new Comparator<Interval>(){
			@Override
			public int compare(Interval i1, Interval i2) {
				if(i1.start != i2.start) {
					return i1.start - i2.start;
				} else return i1.end - i2.end;
			}
		});
		
		newIntervals = mergeInterval(newIntervals);
		Interval pre = newIntervals.get(0);
		int start = 0;
		for(int i = 1; i < newIntervals.size(); i++) {
			Interval curr = newIntervals.get(i);
			if(curr.start - pre.end >= time) {
				start = curr.start;
				return start;
			}
			pre = curr;
		}
		return pre.start;
		
		
	}
	public List<Interval> mergeInterval(List<Interval> intervals) {
		List<Interval> rst = new ArrayList<Interval>();
		if(intervals.size() == 0) return rst;
		
		Interval pre = intervals.get(0);
		for(int i = 1; i < intervals.size(); i++) {
			Interval curr = intervals.get(i);
			if(pre.end < curr.start) {
				rst.add(pre);
				pre = curr;
			} else {//overlapped, need to merge
				pre.end = Math.max(pre.end, curr.end);
			}
		}
		rst.add(pre);
		return rst;
	}
}
