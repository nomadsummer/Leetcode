package google.phone;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Grid {
    public Grid(){}
    int height;
    int width;
    Map<Integer, Integer> map;// index -> value
    TreeMap<Integer, Set<Integer>> max; // max -> index array
    public Grid(int height, int width){
        this.height = height;
        this.width = width;
        map = new HashMap<>();
        max  = new TreeMap<>();
    }

    public void set(int height, int width, int value) {
        int index = setIndex(height, width);
        if (map.containsKey(index)){
            int oldValue = map.get(index); // get old value
            Set<Integer> oldValueSet = max.get(oldValue);
            oldValueSet.remove(index);
            if (oldValueSet.size()==0)
                max.remove(oldValue);
            if (max.containsKey(value))
                max.get(value).add(index);
            else
                max.computeIfAbsent(value, k->{
                    Set<Integer> set = new HashSet<Integer>();
                    set.add(index);
                    return set;
                });
        }
        else {
            max.computeIfAbsent(value, k->{
                Set<Integer> set = new HashSet<Integer>();
                set.add(index);
                return set;
            });
        }
        map.put(index,value);
    }

    public int setIndex(int height, int width){
        return  height * this.height + width;
    }
    public int getMax(){
        return max.lastKey();
    }
}
