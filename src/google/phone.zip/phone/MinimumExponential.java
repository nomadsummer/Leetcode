package google.phone;

/*
 * input: int n.
function: 将n用2的指数表示，使得指数表达式的个数最少
output : int num（指数的最少个数）
e.g: input = 28
28 = 2^4 + 2^3 + 2^2  => num = 3
28 = 2^5 - 2^2             => num = 2
所以 output = 2
 */
public class MinimumExponential {
public int getMin(int n) {
	if(n <= 0) return 0;
	if(n == 1) return 1;
	if((n&1) == 1) {
		return 1 + Math.min(getMin(n+1), getMin(n-1));
	} else return getMin(n >> 1);
}
}
